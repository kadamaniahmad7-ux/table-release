# Fingerprint attendance on a shared Windows till

Use a dedicated Windows fingerprint reader and Table's current Windows desktop build. An administrator pairs the till in **Management → Workers → Fingerprint attendance**. Each employee enrolls a finger in that panel. **Clock in** and **Clock out** appear on the lock screen after enrollment. Employees keep their password as a fallback, including when the till is offline.

## ZKTeco ZK9500

1. Update the standard 64-bit Windows app to **Table POS 2.0.27** or later. Install the official [ZKTeco driver and ZKFinger SDK for Windows](https://www.zkteco.com/en/Biometrics_Module_SDK/ZKFinger-SDK-for-Windows) supplied by your retailer or ZKTeco. Connect one ZK9500 to the till.
2. Extract the **Table ZK9500 setup** ZIP. Open Windows PowerShell as an administrator in the extracted folder and run `powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File .\Install-Table-ZK9500.ps1`. If Windows blocks the script because of its download origin, review that it came from the Table release and unblock the script in its file properties before running it.
3. Table checks for the official SDK in the Windows system directories. If your SDK was supplied as a separate DLL folder, a Windows administrator can place the official `libzkfp.dll` and its matching native dependencies in `%ProgramFiles%\Table POS Fingerprint\ZKTeco\x64` or `x86`, according to the SDK binaries. Table runs the capture helper with the appropriate Windows PowerShell architecture.
4. In **Management → Workers → Fingerprint attendance**, refresh and choose **Pair this reader**. Enroll two employees, lifting and replacing the same finger for the second impression. Test clock-in and clock-out for each employee on the lock screen and verify the four records in attendance. Try an unenrolled finger and check that it creates no record.

The reader captures the impression, and Table identifies the employee on the till using encrypted local templates. The payroll server receives the signed attendance proof. Windows Hello enrollment is unnecessary. The scripts also leave existing Windows and vendor configurations available. If switching a till from an existing provider, unpair the station before changing `reader.json`, then pair and enroll again.

## Windows Biometric Framework readers

1. Install the manufacturer's Windows Biometric Driver Interface (WBDI) driver. Use **Find Windows readers** to get the reader's device instance ID. Windows detection alone does not establish private-pool support.
2. With a Windows administrator, provision a dedicated WBF private pool database for this reader using the driver's supported private-pool configuration. Microsoft's [private pool setup example](https://learn.microsoft.com/en-us/windows/win32/secbiomet/private-pool-setup) shows how to register the database and adapter configuration. Preserve the Windows sign-in reader and its templates. Windows Enhanced Sign-in Security devices do not support this WinBio API. Some Windows configurations also restrict using the last system-pool sensor.
3. In the Windows administrator-managed `%ProgramFiles%\Table POS Fingerprint` directory, save `reader.json` as UTF-8:

   ```json
   {
     "provider": "windows",
     "device": "USB\\VID_0000&PID_0000\\REPLACE_WITH_DEVICE_INSTANCE",
     "databaseId": "00000000-0000-0000-0000-000000000000"
   }
   ```

   Use the actual device instance ID and private database GUID. Set `"mode": "advanced"` if the driver's private pool requires onboard matching. The default mode uses the driver's software matching adapters. Use standard Program Files permissions. Refresh the panel and select **Pair this reader**. Pairing tests whether Table can open the configured database as the till's Windows user. Enroll two employees and verify that each finger records only that employee's attendance.

## Manufacturer adapters

For readers that require a vendor SDK, install a trusted SDK adapter as `adapter.exe` in the same administrator-managed directory. Set `reader.json` to `{"provider":"vendor","id":"vendor-installation-id"}`. Keep the ID stable for this adapter and its template database. The adapter runs as the till's Windows user with one of these argument lists:

| Arguments | Required result |
| --- | --- |
| `probe` | Verify that the reader and its database can open. Print `{"ok":true}`. |
| `enroll <finger>` | Enroll the selected finger. The finger number follows ANSI 381 positions 1–10. Print `{"ok":true,"matchId":"opaque-stable-id"}`. |
| `identify` | Capture and match a fresh sample locally. Return the same `matchId` issued at enrollment. |

Write a single UTF-8 JSON object to standard output. For an expected failure, return `{"ok":false,"error":"no-match"}` with process exit code zero. Other supported error codes are `bad-capture`, `reader-unavailable`, `reader-denied`, and `reader-timeout`. Matching IDs are 1–256 ASCII letters, digits, dots, colons, dashes, or underscores. An already-enrolled finger must resolve to the same ID and must never be reassigned. Keep enrollment under 85 seconds and matching under 26 seconds. Use the vendor's encrypted template store, and keep raw images and templates out of output and logs.

The adapter is trusted to verify fresh samples. Install an adapter you control or have vetted, keep its installation directory writable only by Windows administrators, and run it without administrator privileges. Desktop Table keeps its private station key protected by Windows. The payroll server receives only an opaque station-specific match identifier and a one-time proof. It holds neither images nor biometric templates.

## Table matching with a capture-only reader

Use this mode when a Windows driver or SDK can return a grayscale fingerprint impression. The adapter captures the impression. Table runs SourceAFIS on the till to enroll and match employees.

1. Install the reader's driver. Place its capture adapter as `adapter.exe` and the Table matcher as `TableFingerprintMatcher.exe` in the administrator-managed directory above.
2. Set `reader.json` to `{"provider":"capture","id":"capture-implementation-id"}`. Keep the ID stable while using the same adapter and template store.
3. If the till already uses a matching provider, unpair the reader first. Open **Management → Workers → Fingerprint attendance**, pair this till, and enroll each employee again. Lift and replace the same finger for the two enrollment impressions.

For the capture adapter, `probe` returns `{"ok":true}` once the device can be opened. Each `capture` returns one fresh image as `{"ok":true,"sample":{"width":288,"height":384,"dpi":500,"pixels":"<base64>"}}`. Supply one 8-bit grayscale byte per pixel, in rows from top to bottom with no padding. Use 0 for black ridges and 255 for white. Report the actual sensor resolution in DPI. Table accepts widths and heights from 32 to 1024 pixels and 250 to 1000 DPI. Write a single UTF-8 JSON object and use the same error codes as the matching adapter. Finish each capture within 18 seconds. An automatic retry or cached impression must never substitute for a fresh scan.

Build the standalone matcher with the .NET 8 SDK from the Table repository:

```powershell
dotnet publish electron/fingerprint-matcher/TableFingerprintMatcher.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:EnableCompressionInSingleFile=true -p:DebugType=None -p:DebugSymbols=false -o out/fingerprint-matcher
```

This mode stores only encrypted fingerprint templates on the till. Capture images are processed in memory. Table confirms enrollment with two matching impressions and declines uncertain matches. The capture adapter gets neither employee identities nor stored templates. The POS API receives the same signed attendance proof used by the other reader modes.

The encrypted galleries are in the Windows till app's user-data directory under `attendance-reader\templates`. They are scoped per shop and adapter. Removing access stops the employee from punching with that enrollment. A Windows administrator can clear the local galleries during decommissioning, which requires employees to enroll again. Keep `attendance-reader\station-key` in place unless replacing the whole station.

**Remove access** and **Unpair reader** revoke Table attendance access immediately. In the Windows and manufacturer matching modes, use the private database or vendor's template management tools to delete local templates. Unpair an old station before replacing its device or Windows profile. The attendance API uses database migration `039_pos_fingerprint_stations.sql`.
