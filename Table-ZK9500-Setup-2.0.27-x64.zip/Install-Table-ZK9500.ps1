#Requires -RunAsAdministrator

$ErrorActionPreference = 'Stop'
if (-not [Environment]::Is64BitOperatingSystem) { throw 'Table fingerprint attendance requires 64-bit Windows.' }

$source = Join-Path $PSScriptRoot 'TableFingerprintMatcher.exe'
if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw 'Extract the whole Table ZK9500 setup ZIP before running this script.' }

$directory = Join-Path $env:ProgramW6432 'Table POS Fingerprint'
$config = Join-Path $directory 'reader.json'
if (Test-Path -LiteralPath $config) {
  $previous = Get-Content -LiteralPath $config -Raw | ConvertFrom-Json
  if ($previous.provider -ne 'zkteco') { throw 'A different fingerprint reader is configured. Unpair that reader in Table before changing its setup.' }
}

$probe = & $source --probe | ConvertFrom-Json
if (-not $probe.ok) { throw 'The Table fingerprint matcher failed its self-check.' }

New-Item -ItemType Directory -Force -Path $directory | Out-Null
Copy-Item -LiteralPath $source -Destination (Join-Path $directory 'TableFingerprintMatcher.exe') -Force
if (-not (Test-Path -LiteralPath $config)) {
  [IO.File]::WriteAllText($config, '{"provider":"zkteco"}', [Text.Encoding]::ASCII)
}
Write-Output 'Table ZK9500 setup installed. Open Management > Workers > Fingerprint attendance in the Windows Table app and pair this reader.'
